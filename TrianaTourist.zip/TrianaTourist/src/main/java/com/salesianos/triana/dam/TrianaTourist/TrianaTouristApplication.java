package com.salesianos.triana.dam.TrianaTourist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrianaTouristApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrianaTouristApplication.class, args);
	}

}
